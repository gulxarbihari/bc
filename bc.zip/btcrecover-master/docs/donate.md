# If this tool or other content on my YouTube channel was helpful, feel free to send a tip to: #
## Donate Bitcoin ##
![Donate Bitcoin](donate-btc-qr.png)

BTC: 37N7B7sdHahCXTcMJgEnHz7YmiR4bEqCrS
## Donate Bitcoin Cash ##
![Donate Bitcoin Cash](donate-bch-qr.png)

BCH: qpvjee5vwwsv78xc28kwgd3m9mnn5adargxd94kmrt
## Donate Litecoin ##
![Donate Litecoin](donate-ltc-qr.png)

LTC: M966MQte7agAzdCZe5ssHo7g9VriwXgyqM
## Donate Ethereum ##
![Donate Ethereum](donate-eth-qr.png)

ETH: 0x72343f2806428dbbc2C11a83A1844912184b4243

## Donate Bitcoin to Gurnec ##
This tool builds on the original work of Gurnec who created it and maintained it until late 2017. If you find *btcrecover* helpful, please consider a small donation to them too. (I will also be passing on a portion of any tips I recieve at the addys above to them too)

![Donate Bitcoin](gurnec-donate-btc-qr.png)

BTC: 3Au8ZodNHPei7MQiSVAWb7NB2yqsb48GW4

**Thank You!**